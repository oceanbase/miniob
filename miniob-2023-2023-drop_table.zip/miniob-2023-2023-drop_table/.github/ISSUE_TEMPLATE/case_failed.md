---
name: Case Failed
about: Report a failed case.
title: "[2023 Case Failed]: "
labels: case_failed
---

**base on**: <!-- commit ID -->

**description**: description <!-- bug desc, code block, diff result, how to reproduce, reasons -->
