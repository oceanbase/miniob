# 构建
docker-compose build

# 启动容器
docker-compose up -d

-d 表示后台启动

# 进入容器
docker exec -it miniob bash
